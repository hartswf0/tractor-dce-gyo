# Butter 24 — real construction references

Open WAG-HAND-BUTTER-24.HTML in a desktop or mobile browser. In Workshop → Manual, expand **Six real construction references · no AI**. Choose a kit and subassembly, then Inspect geometry. Return to my build restores your stage. Copy subassembly to new stage creates an editable draft without replacing the original stage. Inspect findings before keeping an unverified assembly.

## Six source benchmarks

| Set | Model | LDraw author | What it exercises |
|---|---|---|---|
| 75954-1 | Hogwarts Great Hall | Stefan Frenz [smf] | Architectural hierarchy, tower, roof and detail |
| 21325 | Medieval Blacksmith | Vincent Messenet [Cheenzo] | Deep submodel hierarchy and repeated assemblies |
| 6080 | King's Castle | Stefan Frenz [smf] | Large enclosure and modular walls |
| 6285 | Black Seas Barracuda | Philippe Hurbain [Philo] | Complex transforms, rigid assemblies and flexible helper geometry |
| 6071 | Forestmen's Crossing | Takeshi Takahashi [RainbowDolphin] | Bridge and terrain assembly |
| 6066 | Camouflaged Outpost | Takeshi Takahashi [RainbowDolphin] | Compact terrain and architectural construction |

Hogwarts is Great Hall 75954, not Hogwarts Castle 71043. These are community LDraw reconstructions, not official LEGO instruction PDFs. Source STEP/ROTSTEP markers and submodel hierarchy are retained; they do not certify that every source step is an independently stable assembly. Expanded leaf placements are not retail piece counts: flexible rope geometry in particular contains many helper segments.

## Changes

- Embedded actual MPDs and their recursive geometry dependencies. Reference mode preserves source transforms and colors; it fits the display without changing the source. Repeated parts share parsed geometry and loading reports placement counts.
- Structural family retrieval supplies pins, clips, brackets and slopes instead of unrelated character props and stickers. Loaded candidates and up to two small attributed source assemblies enter chapter context.
- Dependency context describes actual installed parts, modeled port positions and unresolved findings. A planned connector is no longer reported as an installed connector.
- One paid repair attempt per chapter draft. A candidate with an equal or worse check score cannot replace the previous draft. A new design-generation run resets the allowance; no background automatic retry loop.
- Local checks distinguish new unsupported geometry from inherited uncertain support and missing connector metadata. Unsupported geometry remains blocked; metadata gaps are not presented as physical validation.
- Saved-project import loads referenced geometry before validation.

## Limits

This is not a complete LEGO connection or mechanical simulation engine. Many LDraw parts have geometry but no connector metadata. Conservative bounding-box overlap checks can over-report collisions. Existing ISS final-chapter geometry still has 27 unsupported new pieces and five pieces touching unknown connector geometry; stopping repeated repair spending does not repair those placements.

Editable copying is limited to rigid subassemblies of at most 500 placements, 48 source steps and bench dimensions. Reflected/scaled transforms and flexible helpers remain inspection-only. The reference renderer preserves these transforms. Large model rendering still takes time on mobile. Retrieved geometry is evidence, not a guarantee that a new AI design is buildable. No paid live-model quality benchmark was run; API lifecycle tests use a controlled response.

## Validation

See benchmark-report24.json and test24.cjs. Browser checks cover structural search, the actual ISS project import/local check, one-repair enforcement and best-draft preservation, six nonempty source renders, mobile layout, and copying/committing Barracuda's five-placement bench. Source hashes and counts are in benchmarks24/compiled.json. The package preserves author/license headers and includes CAreadme.txt. Existing user projects are not bundled.

## Sources and licensing

Hogwarts: https://library.ldraw.org/library/omr/75954-1.mpd
Other models: https://hartswf0.github.io/tractor-dce-gyo/ldraw/models/ (original filenames and exact URLs in compiled.json).
Geometry retains the original LDraw/CCAL notices, including named authors and source file headers. See benchmarks24/CAreadme.txt. Packaging does not imply LEGO or source-author endorsement.
