from pathlib import Path
import json,re
c=json.loads(Path('benchmarks24/corpus.json').read_text()); titles={'75954-1':'Hogwarts Great Hall','21325':'Medieval Blacksmith','6080':"King’s Castle",'6285':'Black Seas Barracuda','6071':"Forestmen’s Crossing",'6066':'Camouflaged Outpost'}
for m in c['models']:m['title']=titles[m['id']]
# Header names describe geometry, while source author/license records remain intact in the corpus.
index=[]
for name,text in c['parts'].items():
 if '/'in name or not name.endswith('.dat') or ('parts/'+name) not in c['parts']:continue
 first=text.splitlines()[0] if text.splitlines() else ''
 title=re.sub(r'^0\s*','',first).strip()
 if title.startswith(('~','_','!')) or re.search(r'primitive|subpart',title,re.I):continue
 index.append({'id':name[:-4],'name':title,'category':'Structural corpus'})
c['index']=index
Path('benchmarks24/compiled.json').write_text(json.dumps(c,separators=(',',':')))
s=Path('WAG-HAND-BUTTER-23.HTML').read_text()
pre='<script>'+Path('benchmark-kernel24.js').read_text()+'\nwindow.ButterCorpus24='+json.dumps(c,separators=(',',':')).replace('</','<\\/')+';</script>'
s=s.replace('<script data-butter-module="workspace13">',pre+'<script data-butter-module="workspace13">')
s=s.replace('window.ButterWorkspace={',Path('workshop24.js').read_text()+'\nwindow.ButterWorkspace={')
s=s.replace("localStorage.getItem('butter23-workspace')||","localStorage.getItem('butter24-workspace')||localStorage.getItem('butter23-workspace')||")
s=s.replace("localStorage.setItem('butter23-workspace'","localStorage.setItem('butter24-workspace'")
s=s.replace('Return unresolved obligations honestly.','Return unresolved obligations honestly. Dependencies list actual installed ports and unresolved limitations; never assume a planned socket exists. Reference examples are attributed native LDraw y-down transforms: adapt them to the supplied Butter bottom-origin system. Preserve intentional mechanisms; request missing part families instead of substituting stickers or minifigure props. Do not claim hinges rotate unless geometry and a joint are actually provided.')
s=s.replace('const item=ButterMovieatorIndex.find(p=>p.id===id);','const item=ButterMovieatorIndex.find(p=>p.id===id);')
s=s.replace('</body></html>','<style>#references24 select{display:block;width:100%;margin:8px 0;font-size:14px;padding:9px}#referenceStatus24{font-size:12px;line-height:1.5}#references24 a{color:#c4f46a}#references24 button{margin:3px 0}</style></body></html>')
Path('WAG-HAND-BUTTER-24.HTML').write_text(s)
print('Built',len(s),'bytes;',len(index),'structural headers')
