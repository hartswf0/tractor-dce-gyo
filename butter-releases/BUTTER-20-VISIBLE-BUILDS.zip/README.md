# Butter 20 — visible sketches and blank stages

Open WAG-HAND-BUTTER-20.HTML. Changes from 19:

- Sketch intersections stay visible and are reported instead of causing the entire AI response to disappear.
- Vertical base position is editable in brick courses. AI can place torsos above legs and heads above necks.
- Build all appears beside the composer when a whole sketch is active. Workshop → Sketch also has Build whole sketch. It unions occupied cells and tiles them into actual LDraw bricks, so intersecting rough volumes do not create duplicate overlapping bricks.
- New blank stage is in both Scenes and Sketch. It preserves the current stage.
- Reset this stage creates a backup stage first, then clears the current stage. Swipe to recover the backup. Reset refuses if all 16 stage slots are occupied.
- Recover last unseen AI sketch reopens a completed sketch response retained in this browser's log. Open sketch from AI log accepts exported butter-ai-log JSON. You can recover the Horse responses without spending another API request.
- Horse example is a local authored 45-brick example. It verifies elevated body/head support; it is not presented as model-generated.

## Quick test

Workshop → Sketch → Horse example → Build all. Actual bricks should appear. Open Scenes → Reset this stage; the stage empties, and a before-reset backup stays available. New blank stage creates a separate empty stage.

To recover the attached failure, Workshop → Sketch → Open sketch from AI log, select butter-ai-log (3).json, then Build all. The last Horse response was tested and compiled to 64 bricks. Its proportions/layout remain the original model's rough proposal; recovery does not claim to redesign it into a better horse.

AI uses the existing connection and model settings with the sketch pathway's 90-second limit and 5,000 output-token cap. Invalid data or unsupported physical arrangements still produce explicit errors; rough intersections alone no longer reject a proposal. No automatic repair loop.

## Assembly limits

Whole compilation checks modeled stud paths to floor, not calibrated structural strength. Floating geometry remains a visible sketch with a support diagnostic. It merges overlapping occupied cells; the first volume supplies color where colors conflict. It uses a small verified brick set, not arbitrary LDraw connector solving. The 1,000 installed-piece limit remains.

Whole compilation can create bricks shared by multiple components. A manual parameter edit of a unified build returns the combined model to sketch before recompiling, so shared bricks are not silently removed from a neighbor. Fully incremental shared-boundary rebuilds are not implemented. Direct hand changes are not inferred back into parametric geometry. History integration remains experimental. Physics is paused on sketch stages.

Stage and assembly exports retain editable state; MPD and ordinary scene exports retain actual installed bricks only. Browser quota can fill: export files to keep work.

## Gateway and source

Node 20+: set OPENAI_API_KEY, run node server.mjs, and open http://127.0.0.1:8787. Choose Private gateway under AI with http://127.0.0.1:8787/api/responses. For network binding use GATEWAY_TOKEN and ALLOWED_ORIGIN. Not deployed.

From source/, run python3 make20.py to regenerate the standalone HTML. test20.cjs exercises actual horse compilation, new blank stage, reset and backup restoration, recovery of the real failed response, and mobile no-scroll layout. It references the user's log fixture by local path; supply your copy there. Browser paths need adjustment outside the supplied runtime. No paid live API call was used in verification.
