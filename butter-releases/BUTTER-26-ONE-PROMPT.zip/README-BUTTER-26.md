# Butter 26 — one prompt to a saved build

Open WAG-HAND-BUTTER-26.HTML. Connect the AI provider in Workshop → AI if needed. Type what to build and send. Reference lookup, planning, part retrieval, chapter scheduling, local checking and saving run without manual recipe selection or chapter confirmation. The first section is requested as a recognizable silhouette rather than a foundation slab.

The main screen has a status line, input, Build/Stop and optional Details. Existing top/bottom controls remain. Type “new blank stage” to start separately, or “reset stage” to reset with a backup. Swipe to revisit other stages. The first fresh build creates its own blank stage and preserves the original.

A run plans at most four sections and 600 pieces. It saves each section whose local checks contain no hard failures. Missing connector metadata stays explicitly unverified. One repair attempt is allowed across the run, additionally respecting the existing per-draft repair limit. A still-invalid draft stays visible and the builder stops spending until a new instruction. Stop aborts an active API request and prevents subsequent requests; a part download already in flight may finish before the run unwinds. No background run resumes automatically after reopening.

Describe a change to revise the pending or selected section. Dependent stale sections are rebuilt in dependency order. Optional Details provides section selection, logs, reference inspection, manual tools and exports. Successful recipe-informed sections become saved recipes with provenance and local check history.

## Verified

Controlled browser/API tests at 393×780 passed:
- One user submit makes a plan and two dependent construction calls, saving both sections without manual intervention.
- The manual card is hidden on the primary screen; the input remains above the footer and the outer page does not scroll.
- Committed adaptations become reusable recipes.
- A failed revision attempts repair once, retains the installed scene and keeps the invalid draft visible.
- Stop preserves installed pieces and terminates the active request.
- No JavaScript runtime errors occurred.

Tests use deterministic API responses, not live-model quality evaluation. This revision removes workflow gates; it does not establish reliable physical construction for arbitrary prompts. Existing collision and connector limitations remain. Bounds checks can be conservative and LDraw geometry does not universally include connection metadata. “Local checks passed” is not a physical stability test. Uncertain connections may be saved, with their uncertainty reported.

The HTML includes the existing six-model reference corpus and author/license notices. This package includes the Butter 25 base, incremental source and builder script, browser test and LDraw agreement. Run make26.py to rebuild. The browser test uses Playwright and the build environment's Chromium paths; adjust those paths for another machine.
