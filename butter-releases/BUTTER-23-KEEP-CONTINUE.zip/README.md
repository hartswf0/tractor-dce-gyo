# Butter 23 — keep and continue

Open WAG-HAND-BUTTER-23.HTML and resume your stage. If the old stage does not appear in this browser origin, import its build-project JSON under Manual → Save, open & recover → Open build document.

The primary manual action now reflects what can actually happen:

- Blocked chapter: Finish chapter N opens its earliest unfinished prerequisite and displays its complete draft, without a model request.
- Checked draft: Keep & continue is available from ANY instruction page. It installs the whole chapter and selects the next available chapter.
- Missing connection metadata: Keep unverified & continue explicitly saves the geometry with its unverified status.
- Definite geometry findings: Repair chapter makes an explicit model request with those findings. The draft and findings stay accessible on the manual itself.
- Changed supporting chapter: Recheck chapter recalculates checks locally, then offers a keep action. Scene changes since draft creation also trigger a local recheck instead of a cryptic stale-scene error.
- All chapters saved: Build saved; no further request.

Use header arrows or swipe on the manual to inspect pages separately from committing. Swiping pages never calls AI. Resume build resolves prerequisites automatically. No automatic paid chain or repair is started by a commit.

Manual contents reopen at the top, with advanced diagnostics collapsed. Hidden file inputs no longer leak into the interface. Prior versions' build-project files remain supported. Word-to-World and Volume sketch remain available.

Tests: mobile Chromium, 393×780, actual button clicks. Tested blocked chapter → prerequisite → keep directly from page 1 → next chapter unlocked; explicit unverified commit retains verified:false; stale chapter recheck and recommit; completion state; hidden file input; no page scroll or JS errors. These exercise the reported flow using authored geometry and simulated missing connector metadata. The screenshots supplied for this version did not include the specific new build's project or log, so its individual geometry findings were not reproduced. No paid AI request was made during these tests.

Build: python3 make23.py from source/. Browser test requires Playwright and the workspace Chromium runtime. Gateway is optional, unchanged from 22, and must be configured separately. This is a downloadable build, not a deployment to GitHub Pages.
