from pathlib import Path
s=Path('WAG-HAND-BUTTER-22.HTML').read_text()
s=s.replace('window.ButterWorkspace={',Path('flow23.js').read_text()+'\nwindow.ButterWorkspace={')
s=s.replace("localStorage.getItem('butter22-workspace')||","localStorage.getItem('butter23-workspace')||localStorage.getItem('butter22-workspace')||")
s=s.replace("localStorage.setItem('butter22-workspace'","localStorage.setItem('butter23-workspace'")
s=s.replace('</body></html>','''<style>#drawer14 input[hidden],#findings23[hidden]{display:none!important}#findings23{font:11px/1.4 system-ui;margin:3px 0;flex-shrink:0}#findings23 p{white-space:pre-line;max-height:90px;overflow:auto}#pageBody22:has(#findings23[open]){overflow:auto}#manual22 #forward22{max-width:62%;min-height:38px}#manual22 #nextPage23{font-size:19px;min-width:30px}#manual22 #back22{font-size:19px;min-width:30px}</style></body></html>''')
Path('WAG-HAND-BUTTER-23.HTML').write_text(s)
