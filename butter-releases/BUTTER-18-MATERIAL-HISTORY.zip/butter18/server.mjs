import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {Readable} from 'node:stream';
import {timingSafeEqual} from 'node:crypto';
const port=Number(process.env.PORT||8787),host=process.env.HOST||'127.0.0.1';
const key=process.env.OPENAI_API_KEY||'',token=process.env.GATEWAY_TOKEN||'';
const origins=new Set((process.env.ALLOWED_ORIGIN||`http://localhost:${port},http://127.0.0.1:${port}`).split(',').map(s=>s.trim()).filter(Boolean));
if(!['127.0.0.1','localhost','::1'].includes(host)&&(!token||!process.env.ALLOWED_ORIGIN))throw Error('Network binding requires GATEWAY_TOKEN and an explicit ALLOWED_ORIGIN.');
const equal=(a,b)=>{const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y);};
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost'),origin=req.headers.origin;
 if(url.pathname==='/'||url.pathname==='/WAG-HAND-BUTTER-18.HTML'){
  if(req.method!=='GET'){json(res,405,{error:{message:'GET required.'}});return;}
  try{const page=await readFile(new URL('./WAG-HAND-BUTTER-18.HTML',import.meta.url));res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(page);}catch{json(res,500,{error:{message:'Place WAG-HAND-BUTTER-18.HTML beside server.mjs.'}});}return;
 }
 if(url.pathname==='/health'){json(res,200,{gateway:'butter-15',keyConfigured:!!key});return;}
 if(!url.pathname.startsWith('/api/')){json(res,404,{error:{message:'Not found.'}});return;}
 const originOK=!!origin&&origins.has(origin);
 if(originOK){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Allow-Methods','POST, GET, OPTIONS');res.setHeader('Access-Control-Expose-Headers','x-request-id');}
 if(req.method==='OPTIONS'){if(!originOK){json(res,403,{error:{message:'Origin not allowed.'}});return;}res.writeHead(204);res.end();return;}
 const authenticated=!!token&&equal(String(req.headers.authorization||''),'Bearer '+token);
 if((token&&!authenticated)||(!token&&!originOK)){json(res,403,{error:{message:token?'Gateway access token required.':'Origin not allowed.'}});return;}
 if(origin&&!originOK){json(res,403,{error:{message:'Origin not allowed.'}});return;}
 let upstreamPath;if(url.pathname==='/api/responses'&&req.method==='POST')upstreamPath='/v1/responses';else if(/^\/api\/models\/[a-zA-Z0-9_.:-]+$/.test(url.pathname)&&req.method==='GET')upstreamPath='/v1/models/'+url.pathname.split('/').at(-1);else{json(res,404,{error:{message:'Unsupported API route.'}});return;}
 if(!key){json(res,503,{error:{message:'Set OPENAI_API_KEY on the gateway server.'}});return;}
 const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),180000);res.on('close',()=>{if(!res.writableEnded)ctl.abort();});
 try{let body;if(req.method==='POST'){let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>512000){json(res,413,{error:{message:'Request exceeds 512 KB.'}});return;}chunks.push(chunk);}body=Buffer.concat(chunks).toString();let doc;try{doc=JSON.parse(body);}catch{json(res,400,{error:{message:'Invalid JSON.'}});return;}if(typeof doc.model!=='string'||!doc.input){json(res,400,{error:{message:'Model and input required.'}});return;}}
 const upstream=await fetch('https://api.openai.com'+upstreamPath,{method:req.method,headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body,signal:ctl.signal});
 res.writeHead(upstream.status,{'Content-Type':upstream.headers.get('content-type')||'application/json','Cache-Control':'no-cache, no-transform','X-Accel-Buffering':'no',...(upstream.headers.get('x-request-id')?{'x-request-id':upstream.headers.get('x-request-id')}:{})});res.flushHeaders();
 if(upstream.body){const stream=Readable.fromWeb(upstream.body);await new Promise((resolve,reject)=>{stream.on('error',reject);res.on('finish',resolve);res.on('close',resolve);stream.pipe(res);});}else res.end();
 }catch(e){if(!res.headersSent)json(res,502,{error:{message:e.name==='AbortError'?'Upstream request timed out.':'Gateway could not reach OpenAI.'}});else res.destroy();}finally{clearTimeout(timer);}
});
server.listen(port,host,()=>console.log(`Butter gateway listening on http://${host}:${port}; API key ${key?'configured':'missing'}.`));
