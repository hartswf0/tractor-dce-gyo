# Butter 18 — material history workshop

Open WAG-HAND-BUTTER-18.HTML. Existing top/bottom controls, hand manipulation, swipeable stages, and the word-to-world builder are retained. This is a working case-study sandbox, not a calibrated model of decades of material degradation.

## Start without an API

1. Open Workshop → History → Open lighthouse case study.
2. In Make a change, apply Storm. The exposed top piece moves into salvage with its original identity and placement.
3. Apply Repair. The same salvaged piece returns if placement, connections, protected pieces and floor access pass.
4. Open History & branches → Compare storm → repair / repair → storm. Close the drawer and swipe between the resulting stages.
5. Inspect an event and branch from it. The parent history is preserved.

The authored 56-piece lighthouse is a deterministic demonstration seed compiled through the shared word-to-world DSL. It is not presented as a live LLM-generated result.

## Use the LLM

Configure your API connection under AI. Under History, describe a historical change and choose Propose history with AI. The model receives current installed pieces, salvage, metadata, protected constraints and connector information. It returns at most eight typed events. Each is checked and applied atomically. If a later event fails, earlier accepted events remain and the failure is recorded; the entire sequence is not an all-or-nothing transaction.

Allowed events: wear, storm, repair, move, clutter from salvage, substitute using salvage, and layer/role assignment. Unknown stock and invalid placements are rejected. The history proposal uses the existing Responses API connection, visible progress/stop controls, and per-stage model settings. API calls can incur charges. Tests used controlled responses, not a live paid model.

For broader geometry changes, use the regular chat builder. When history is enabled, its instructions include stock and prior events. Installed or salvaged pieces retain identities when reused. By default AI edits cannot acquire new stock; uncheck the stock restriction in History to allow purchases. Direct hand additions are recorded as acquisitions. Direct completed piece edits are recorded through the existing persistence hook.

## What is recorded

The exported ledger contains a baseline, compiler/engine versions, accepted ordered events, reversible sparse per-entity patches, timestamps, proposal/source provenance, check results, and periodic checkpoints. Rejected proposals are separate attempts. Baseline geometry is preserved rather than assuming a seed can recreate an LLM response. Hashes detect ordinary replay divergence; they are not cryptographic signatures.

Piece metadata distinguishes temporal layer (Structure, Space Plan, Stuff), represented wear, role, repairs and substitution lineage. Layer wear rates are authored parameters. Wear changes represented condition and informs subsequent choices; it does not silently reduce plastic clutch strength or physically deform meshes. Storm and repair change actual installed geometry and salvage inventory. A no-op accepted repair still appears in the event order.

History workers evaluate event proposals, replay and floor reachability when workers are available. A synchronous fallback is supplied. No sub-5ms performance claim is made.

## Checks and limits

- Geometry is held fixed between events by default to preserve reproducible histories. Run physics between events is an explicit experimental option.
- Known stud ports establish a connection path to the floor. This is not a calibrated load, fatigue, or stability calculation.
- Conservative bounds reject overlaps, character intersections and off-bench geometry.
- Floor reachability uses a 40×40 grid, 20 LDU cells and a 10 LDU clearance radius between cyan/green corner rings. It does not certify stairs, vertical lantern access, a navmesh, or accessibility compliance.
- Affordance pins preserve designated piece identities, with explicit substitution tracking. They are a proxy for required functions, not a general semantic-function proof.
- Part discovery searches the bundled repository index, loaded parts and compiler catalog. It labels modeled ports versus unverified geometry. It is not exhaustive semantic/connectivity coverage of every LDraw part.
- Word-to-world DSL props (figures/vehicles) and some special-part connections retain the adapter limits documented in Butter 17. Existing Butter cast controls remain available.
- Ledger geometry covers pieces and their conditions. Character actions are not event-sourced; baseline characters are restored when importing a ledger.
- Capacity remains 16 scene versions and 1,000 installed pieces per stage. Export sessions and ledgers because browser storage may fill.

## Save and compare

Export baseline + event ledger saves material history. Open history ledger validates and replays it into a new stage. Verify deterministic replay checks the sequence of patches. Export all scenes retains all stages, experiments, histories and AI logs. Existing scene/MPD exports remain available, but MPD alone cannot preserve this history metadata.

## Optional gateway

Node 20+: set OPENAI_API_KEY in your environment, run `node server.mjs`, then open http://127.0.0.1:8787. Set the app route to Private gateway and the URL to http://127.0.0.1:8787/api/responses.

For hosting, use HTTPS, a GATEWAY_TOKEN, and an explicit ALLOWED_ORIGIN. localhost on a phone means the phone. The gateway is included but has not been deployed.

## Reproduce and test

The source directory includes the Butter 17 base, history kernel, integration, and build script. From source/, run `python3 make18.py` to generate the standalone HTML. Run `node test18-kernel.cjs` for order dependence, layer rates, inverse patches, blocked egress, replay and corruption detection. Browser tests additionally covered storm/salvage/repair identity, branch order, atomic rejection, persistence, hand-edit recording, ledger import, AI event application with controlled responses, stock exhaustion and mobile layout.
