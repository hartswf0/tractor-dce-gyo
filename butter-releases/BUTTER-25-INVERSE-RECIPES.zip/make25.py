from pathlib import Path
s=Path('WAG-HAND-BUTTER-24.HTML').read_text()
s=s.replace('<title>WAG / HAND BUTTER</title>','<title>WAG / BUTTER 25 — Construction recipes</title>')
s=s.replace('window.ButterWorkspace={',Path('recipes25.js').read_text()+'\n'+Path('workshop25.js').read_text()+'\nwindow.ButterWorkspace={')
s=s.replace("localStorage.getItem('butter24-workspace')||","localStorage.getItem('butter25-workspace')||localStorage.getItem('butter24-workspace')||")
s=s.replace("localStorage.setItem('butter24-workspace'","localStorage.setItem('butter25-workspace'")
s=s.replace('</body></html>','<style>#recipes25{padding:10px 0}#recipePrompt25{width:100%;box-sizing:border-box;font-size:16px;padding:12px}#recipeResults25{max-height:24dvh;overflow:auto;margin:8px 0}#recipes25 .recipe25{display:flex;gap:12px;padding:12px 4px;border-bottom:1px solid #425552}#recipes25 .recipe25 input{width:22px;height:22px;flex-shrink:0}.recipe25 b,.recipe25 small{display:block}.recipe25 small,#recipeStatus25{font-size:12px;line-height:1.5}.recipe25 details{font-size:12px}.recipe25 p{overflow-wrap:anywhere}#rough25{background:#c4f46a;color:#122722;width:100%}#recipes25 button{margin:6px 0}</style></body></html>')
Path('WAG-HAND-BUTTER-25.HTML').write_text(s)
