# Butter 25 — inverse construction recipes

Open WAG-HAND-BUTTER-25.HTML. On a blank stage, type an idea such as **lighthouse**, **station**, **window** or **roof**. The manual searches actual source assemblies before making any AI request. Select up to three and choose **Rough out selected · no AI**.

## What is implemented

129 candidate recipes are extracted from the six LDraw references shipped with Butter 24. Each has a source assembly name, actual placement count, parts inventory, source-step count, author, source URL, model hash, transformation limits and source geometry. Numbered step names stay numbered: the application does not pretend it has inferred an architectural function from them.

Search uses literal source/part names and a small explicit synonym map. For example, lighthouse searches tower, roof and lamp. This is retrieval, not an LLM-generated semantic understanding of the corpus.

Rough out prepares actual geometry, preserves internal transforms, centers the study on a new stage and lays multiple recipes out separately. It does not claim they are connected or that the result already satisfies the brief. Existing stages remain available. Source pages become manual pages. Embedded custom parts receive stable local IDs so they can be loaded and saved without relying on invalid part paths.

Review the local findings and keep the chapter. To develop it, open **Workshop → Manual → Develop this build**. Enter the missing construction in the description field, then choose **Add missing section**. This creates a new dependent chapter without an API request. **Write chapter** makes the explicit AI request using installed geometry, dependency facts and recipe provenance. Existing pieces remain installed while the new chapter is drafted. To revise the source assembly itself, select that chapter and describe the change in the main composer.

Committed recipe-derived chapters become searchable saved recipes in the current workspace. The saved project carries provenance, revisions, check results and up to twelve recent adaptation attempts. This is local project reuse, not model training or a shared cloud recipe database. Export the project or workspace to retain it outside browser storage.

**Write a fresh AI plan** remains available when retrieval has no useful source match. Butter 24's single paid repair allowance and best-draft preservation remain in force.

## Validation and limits

Browser checks passed at a 393×780 viewport:
- Lighthouse retrieval includes tower-roof and lamp candidates; initial search makes zero API calls.
- A five-placement source bench becomes a draft on a new stage, commits with its connection uncertainty recorded, and becomes searchable as a saved recipe.
- Bench and lamp compose as ten actual placements without an API call, including an embedded custom lamp part.
- A missing-section chapter depends on the installed source chapter. A controlled API response adds one new part without changing the five source placements. The adaptation attempt is recorded.
- The outer page does not scroll; recipe search scrolls within the workshop. No runtime errors occurred in these tests.

AI tests used a deterministic mock response, not a paid live-model quality evaluation. The implementation does not yet infer support graphs from every LDraw mesh, synthesize universally valid joins, discover arbitrary parameterized construction grammars, or guarantee physical stability. Source translation is implemented; arbitrary scaling and reflected editable geometry are rejected. Source rotations are retained. Some recipes may require unsupported colors or exceed the editable bench and are rejected with a message; use the original reference viewer for those models.

The initial rough-out is a study of retrieved constructions. Fulfilling a new brief still requires composition and adaptation. A known model is evidence of source geometry, not proof that an isolated subassembly stands alone. Existing conservative collision and connector checks remain imperfect. Uncertainty is not converted into a physical-validation claim.

## Files

- WAG-HAND-BUTTER-25.HTML: self-contained application with reference geometry.
- recipes25.js: source recipe extraction and explicitly defined retrieval aliases.
- workshop25.js: recipe selection, visible study, source-safe copying, missing-section chapters, saved recipes and attempt history.
- make25.py: builds from included Butter 24 HTML.
- test25.cjs, test25-compose.cjs, test25-ai.cjs: browser tests; require Playwright and Chromium. The test browser paths reflect the build environment and may need updating.

Source author and license notices remain embedded in the corpus. See the Butter 24 package for the original MPDs and detailed benchmark attribution, and included CAreadme.txt for the LDraw library agreement. Hogwarts refers to Great Hall 75954, not set 71043.
