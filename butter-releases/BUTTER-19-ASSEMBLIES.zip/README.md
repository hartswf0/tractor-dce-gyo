# Butter 19 — sketch to assemblies

Open WAG-HAND-BUTTER-19.HTML. Workshop → Sketch → New castle sketch works without an API. It opens an empty stage and preserves the previous stage. Close Workshop to see the volumes.

## Try it

1. Tap a volume. Its name and estimated brick count appear beside the composer.
2. Drag the volume on the floor. Placement snaps to studs; overlapping or off-bench footprints are rejected.
3. Tap Build beside the composer. Only the selected component becomes actual LDraw bricks.
4. Workshop → Sketch exposes width, depth, height and position for the selected component. Updating a built component returns only that component to sketch. Rebuild it when ready.
5. Undo assembly edit reverses the latest component operation. It has eight checkpoints. Typing `undo` on a sketch stage uses this history.
6. Duplicate a stage in Scenes, then swipe between stages. Each copy has independent component parameters and installed parts.
7. Save through Sketch → Save & restore assemblies → Export sketch + bricks. Open assembly file restores to a new stage. Export all scenes retains the workspace, per-stage instructions and AI logs. MPD/ordinary scene exports contain actual bricks, not unbuilt volumes or hierarchy.

The authored castle example has nine subassemblies. The test arrangement, after lowering one tower from eight to six courses, compiled to 379 bricks. The demo is deterministic local geometry, not an AI-generated result.

## AI

Configure the existing AI connection in Workshop → AI. Type a request in the composer to rough out a layout. Without a current sketch, an accepted layout opens in a new empty stage; it never falls back to placing a new building over existing pieces. On a sketch stage it revises the current layout. Select a component to restrict the request to that component; changes to others are rejected before installation.

AI proposes component parameters, not individual brick placement. Each request uses the selected model, the stage's custom instructions, medium reasoning, at most 5,000 output tokens, and a 90-second wall-clock limit. The existing reasoning dropdown remains for legacy full DSL/history tools; the sketch pathway deliberately uses its own fixed budget. The stop button aborts a pending sketch. Errors preserve existing work and appear in the composer status and AI log. There are no automatic repair or review calls. Actual latency depends on the selected model and service.

After accepting parameters, the local compiler builds selected components without another API call. It places brick courses, spans the doorway with a four-stud lintel, checks conservative brick intersections, and verifies modeled stud connectivity to the floor. A failed check leaves the component as a sketch.

This build was tested with controlled API responses. No paid live AI generation was used to validate design quality.

## Supported assemblies and limits

- Hollow rectangular tower (at least 3 × 3 studs), rectangular wall, solid rectangular block, and one-course-deep gate with a two-stud-wide, three-course-high opening.
- 1–16 components; widths/depths 1–16 studs; heights 1–18 brick courses; footprints inside [-18,18] studs.
- Every component stands independently on the floor. Adjacent components are NOT cross-bonded. Vertical stacking, shared foundations, roofs, explicit dependency propagation and arbitrary attachment ports are future work.
- Components compile using known bricks 3001, 3003, 3004, 3005 and lintel 3010. The wider LDraw repository remains available in Butter, but this compiler does not promise verified assemblies from every part.
- Physics is paused on sketch stages. Verified stud paths are not calibrated strength, stability or load tests.
- The stage cap is 1,000 installed pieces. You may leave other components rough.
- Assembly sketches use floor-plan rectangles for conservative overlap checks. You cannot nest another assembly inside a hollow tower in this version.
- Direct hand edits to installed bricks are still available. Recompiling or resizing their parent regenerates that assembly from its parameters; it does not infer those hand changes back into the sketch.
- History tools from Butter 18 remain available. This version does not yet reconcile arbitrary historical substitutions back into component parameters. Export before combining these experimental workflows.
- Storage depends on browser quota. Export files for durable backups.

## Gateway

Node 20+: set OPENAI_API_KEY in the environment and run `node server.mjs`. Open http://127.0.0.1:8787, choose Private gateway under AI, and set http://127.0.0.1:8787/api/responses. The HTML can also use its existing direct API option. Never publish keys in the HTML.

For network hosting the supplied server requires GATEWAY_TOKEN and ALLOWED_ORIGIN. This package has not been deployed. On a phone, localhost refers to the phone itself.

## Source and validation

The source folder contains the Butter 18 base plus the small assembly kernel, integration, build script and browser regression tests. Run `python3 make19.py` from source to regenerate the standalone HTML.

Browser tests covered: each castle component's real connection checks; scoped rebuild preserving other component coordinates/identities; overlap rejection; undo; fork isolation; persistence; mobile no-page-scroll; tap selection and contextual Build; snapped dragging; export-data import; API payload budget; valid scoped AI edit; rejection of cross-component AI changes; no automatic retries. Browser tests need Playwright and a Chromium executable; adjust their local runtime paths for your machine.
