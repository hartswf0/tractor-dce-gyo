// Grid-aligned subassemblies. Units: studs in plan, brick courses vertically.
(function(root){
const copy=x=>JSON.parse(JSON.stringify(x));
function validate(cs){if(!Array.isArray(cs)||!cs.length||cs.length>16)throw Error('Use 1–16 assemblies.');const ids=new Set();for(const c of cs){if(!c||typeof c.id!=='string'||!/^[a-zA-Z0-9_-]{1,32}$/.test(c.id)||ids.has(c.id))throw Error('Assembly IDs must be unique.');ids.add(c.id);if(typeof c.name!=='string'||c.name.length>60)throw Error('Use a short assembly name.');if(!['tower','wall','gate','solid'].includes(c.kind))throw Error('Unknown assembly type.');for(const k of ['x','z','w','d','h','color'])if(!Number.isInteger(c[k]))throw Error(k+' must be an integer.');if(c.w<1||c.d<1||c.w>16||c.d>16||c.h<1||c.h>18)throw Error('Size: 1–16 studs, 1–18 courses.');if(Math.min(c.x,c.z)<-18||c.x+c.w>18||c.z+c.d>18)throw Error('Assembly must fit inside the bench.');if(c.kind==='tower'&&(c.w<3||c.d<3))throw Error('Hollow towers need at least 3 × 3 studs.');if(c.kind==='gate'&&(c.w<4||c.d!==1||c.h<4))throw Error('Gate needs width ≥4, depth 1, height ≥4.');}
for(let i=0;i<cs.length;i++)for(let j=i+1;j<cs.length;j++){const a=cs[i],b=cs[j];if(a.x<b.x+b.w&&a.x+a.w>b.x&&a.z<b.z+b.d&&a.z+a.d>b.z)throw Error(a.name+' overlaps '+b.name+'. Move the sketch before building.');}return cs;}
function compile(c){validate([c]);const rows=[];const put=(part,x,z,w,d,y,r=0)=>rows.push({part,color:c.color,x:(c.x+x+w/2)*20,y:y*24,z:(c.z+z+d/2)*20,r});for(let y=0;y<c.h;y++){const cells=Array.from({length:c.d},(_,z)=>Array.from({length:c.w},(_,x)=>c.kind!=='tower'||x===0||z===0||x===c.w-1||z===c.d-1));
 const left=Math.floor((c.w-2)/2);if(c.kind==='gate'&&y<3)for(let x=left;x<left+2;x++)cells[0][x]=false;
 if(c.kind==='gate'&&y===3){put('3010',left-1,0,4,1,y);for(let x=left-1;x<left+3;x++)cells[0][x]=false;}
 const shapes=y%2?[['3001',2,4,1],['3003',2,2,0],['3004',1,2,1],['3004',2,1,0],['3005',1,1,0]]:[['3001',4,2,0],['3003',2,2,0],['3004',2,1,0],['3004',1,2,1],['3005',1,1,0]];
 for(let z=0;z<c.d;z++)for(let x=0;x<c.w;x++){if(!cells[z][x])continue;for(const [part,w,d,r] of shapes){if(x+w>c.w||z+d>c.d)continue;let ok=true;for(let j=z;j<z+d;j++)for(let i=x;i<x+w;i++)if(!cells[j][i])ok=false;if(!ok)continue;put(part,x,z,w,d,y,r);for(let j=z;j<z+d;j++)for(let i=x;i<x+w;i++)cells[j][i]=false;break;}}
 }if(rows.length>600)throw Error('Component exceeds 600 bricks. Reduce its size.');return rows;}
function castle(){return [
 ['nw','Northwest tower','tower',-10,-8,4,4,8],['ne','Northeast tower','tower',6,-8,4,4,8],['sw','Southwest tower','tower',-10,4,4,4,8],['se','Southeast tower','tower',6,4,4,4,8],
 ['north','North wall','wall',-6,-8,12,1,5],['west','West wall','wall',-10,-4,1,8,5],['east','East wall','wall',9,-4,1,8,5],['gate','Gatehouse','gate',-6,7,12,1,5],['keep','Keep','tower',-3,-3,6,6,10]
 ].map(([id,name,kind,x,z,w,d,h])=>({id,name,kind,x,z,w,d,h,color:71}));}
function lighthouse(){return [{id:'tower',name:'Lighthouse tower',kind:'tower',x:-3,z:-3,w:6,d:6,h:12,color:15},{id:'store',name:'Keeper’s store',kind:'gate',x:4,z:0,w:6,d:1,h:5,color:4}];}
root.Assembly19={validate,compile,castle,lighthouse,copy};if(typeof module!=='undefined')module.exports=root.Assembly19;
})(globalThis);
