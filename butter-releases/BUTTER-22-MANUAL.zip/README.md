# Butter 22 — building manual

Open WAG-HAND-BUTTER-22.HTML. Existing top and bottom controls remain. Manual pages sit beneath the stage. Swipe the stage to change scenes; swipe the manual to turn pages. Page turns never request AI or commit geometry.

## Start

Describe a build in the composer. The first request writes a chapter plan. The main action then writes the selected chapter, gathering indexed parts automatically. View ordered pages, their actual LDraw part thumbnails and counts, and the accumulated geometry. Keep chapter commits a checked draft and selects the next available chapter. There is no paid automatic build chain.

Tap Manual for the contents, concept reference, new blank stage and save/open controls. Builder settings and diagnostics are collapsed below the contents. Word-to-World and Volume sketch remain separate choices there. Existing stage reset keeps a backup.

## Continue your movie theater without another generation

Manual → Save, open & recover → Open build document → choose recovered-theater-22.json. Open the Auditorium Floor and Rake chapter. Its five pages contain 165 recovered pieces. The original 224-piece foundation remains committed; the auditorium remains a reviewable draft. Turn through its pages and Keep chapter to install it. The recovered geometry passes the existing body-bounds and modeled-connection checks; this is not certification of real-world strength or assembly insertion paths.

This response was recovered from the supplied AI log with no model request. New arbitrary logs can be imported through Recover instructions from AI log after opening their matching project. Recovery checks the brief, title and assembly ID and skips already saved/drafted chapters.

## Fixes

- Loads color definitions from bundled LDConfig and sends an explicit supported palette, including dark red 320. Unknown codes still produce a visible retained response rather than a silent loss.
- Saves returned instruction JSON before validation. Blocks unchanged resubmission of a rejected response; a written correction includes the prior output and validation error.
- Removes duplicate retrieval data from the selected-assembly context, reduces candidate metadata and coordinate precision, and omits the redundant stage image from assembly calls. Optional concept reference remains.
- Plans request a recognizable first chapter and 3–6 chapters at a modest default scale, rather than a giant foundation-first plan. This is model guidance, not a guaranteed design-quality outcome.
- Only the active unbuilt overview has an outline, rendered with edges rather than triangulated wireframe faces.
- Actual geometry supplies instruction previews and piece tray thumbnails. Current-page pieces keep their colors; prior steps fade.

## Verification

Mobile Chromium at 393×780: real-log recovery produced 165 draft pieces, no overlap/connection findings, and left the installed foundation at 224. Page controls, chapter commit/advance, manual contents and viewport containment passed. Controlled Responses API tests passed composer → plan → gather → two pages → commit with two calls, explicit palette, no duplicate retrieval packet, rejected-output retention, repeat prevention and corrective context. No paid live AI generation was made in this change.

## Limits

Part retrieval remains the bundled 4,934-entry index plus loaded geometry, not the entire LDraw universe or a searchable corpus of kit instructions. Unmodeled connections and conservative bounds may require inspection. Generated instructions may still be long or contain too many parts per page. Storage uses the existing browser workspace; export copies. The source package and standalone file are not deployed to GitHub Pages. Camera permission and API CORS depend on the browser/origin; the supplied gateway is optional and must be configured separately.

Rebuild: run python3 make22.py from source/. Tests additionally expect the supplied theater upload fixtures in upload/ and the Playwright/Chromium runtime used in the workspace. No API secrets are included.
