# Butter 17 — word-to-world builder integration

Open WAG-HAND-BUTTER-17.HTML, or publish that file beside the existing Butter pages. Workshop → AI holds the connection and stage instructions. Existing Butter 16/15/14 stage data is read when served from the same origin. Export your old session before replacing files.

The HTML embeds the actual world/dsl.js and world/ai.js retrieved from hartswf0/tractor-dce-gyo, plus the word-to-world manifest (hash f53c7b15). Source snapshots and the Butter adapter are in source/. It does not embed a second language model or a canned AI response.

## Build behavior

Default: gpt-5.6-sol, max reasoning, up to 64,000 output tokens per call. Stage settings may override model/reasoning/instructions. The shared builder plans larger briefs, designs, compiles, and reviews; its original slow-design review skip remains intact. Butter adds up to two model repairs using compiler and connection diagnostics. This can make several billed calls for one prompt. Each call appears in the exported AI log.

The model receives a stage image. Compiled designs are positioned in available bench space without scaling their parts. The maximum scene size is 1,000 parts (mobile performance depends on device). Requests allow up to 15 minutes overall; initial HTTP connection times out after 30 seconds. The stop control remains available.

Draft geometry remains visible and the original scene remains intact until Apply. Failed connection checks highlight affected pieces. After two unsuccessful repairs, edit the prompt or tap the repair arrow. Stop retains an available draft instead of committing it. Discard returns to the existing scene. Valid drafts create the verified stud bonds before physics resumes.

The shared compiler's result is not a claim of physical validity: it can drop floating pieces or skip blocked special parts. Those diagnostics block assembly and enter the repair loop. Butter uses conservative bounding boxes and modeled stud ports, so some physically plausible special-part connections will still be rejected. Figures/vehicles emitted as DSL props are reported as unsupported by this adapter and enter repair; Butter's existing cast remains available. This is shared builder/compiler integration, not complete parity for every word-to-world prop or physics behavior.

## Exact comparisons and saving

Workshop → Scenes → Save, restore & export:
- Export build program saves the current draft or last applied DSL program.
- Open scene/session also accepts a word-to-world JSON program with an ops array.
- Export all scenes preserves programs, experiments, scene states and logs.
- AI Log → Replay DSL draft recompiles a recorded response without an API call.

After an applied build, the next description edits that program. Duplicated stages inherit the program and their own experiment settings. The live scene is supplied on edit so the model can account for manual changes.

## Optional local gateway (Node 20+)

Set OPENAI_API_KEY in your environment, then run `node server.mjs` and open http://127.0.0.1:8787. Select Private gateway with http://127.0.0.1:8787/api/responses in Workshop → AI. The browser does not forward your OpenAI key to this gateway.

For a hosted gateway, use HTTPS, set GATEWAY_TOKEN, and set ALLOWED_ORIGIN to the precise page origin (for GitHub Pages: https://hartswf0.github.io). Use the separate gateway access-token field. localhost on a phone refers to the phone, not your computer. The gateway is supplied but not deployed.

## Verification

Browser tests with controlled API responses verified:
- actual shared design/review calls; max reasoning, image input, 64K budget;
- identical standalone/compiler rows and matching Butter adapter part/color/position/rotation;
- model repair of a disconnected draft;
- bounded failed repairs retain visible draft and preserve original scene;
- a 264-piece assembly applies and survives stage duplication and reload;
- fixed mobile layout without document scrolling.

No live paid OpenAI build was run here. A working API key/network connection is still required. Downloading newly used LDraw assets also requires network access. The bundled local connection test is explicitly labeled and is not an AI-quality test.
