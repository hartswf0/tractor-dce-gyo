# Butter 21 — build documents

This version rewires the default composer around a persistent build document: design brief, optional concept image, assembly plan, part retrieval, executable instructions, geometry review and explicit commits. It keeps Word-to-World and the volume-sketch compiler as separate per-stage builders.

## Start

Open WAG-HAND-BUTTER-21.HTML, then Workshop → Build.

For a local test, expand Local example and choose Open instruction example. It opens a fresh stage, creates a two-assembly plan, searches the part index, and previews three authored steps. Scrub the instruction slider, inspect the current-step parts tray, then Commit checked draft. This example is an integration test, not a claim of AI design quality.

For your own model:

1. Write a brief in the composer or Build drawer.
2. Optionally upload a reference image, or Generate concept image with the configured API. Concept images are labelled references; their connections are not treated as proven.
3. Write assembly plan. The model specifies named submodels, their envelopes/origins, budgets, dependencies, interfaces, search terms and ordered design obligations. The plan appears in the drawer and wire envelopes appear on the stage.
4. Select an assembly. Forage parts searches actual indexed names and IDs, attempts to load leading candidates, and records their geometry bounds, heights, connector availability and retrieval errors. The tested bundled/loaded index contained 4,934 entries. This is not every LDraw part.
5. Write executable steps. The assembly builder receives the brief, concept image, a whole-plan summary, nearby actual geometry, dependency revisions, retrieved parts, saved technique examples and assembly-specific notes. It returns exact part placements in an ordered step list. The scene is not silently committed.
6. Review the actual geometry. The slider shows cumulative steps and highlights the current step. The tray counts new pieces by part and color. Save this instruction view exports a renderer-generated JPEG, not a generated illustration.
7. Commit checked draft installs only the selected assembly. Other assemblies remain unchanged. Dependencies are versioned; downstream committed assemblies are marked for rechecking when a prerequisite changes. Build/Next advances to another eligible assembly.

Whole design clears the assembly selection. Overall replanning is refused once assemblies are committed; start a separate blank stage to pursue another composition. Current assembly refinements can be entered in the composer or builder notes.

## Three builders

Workshop → Build → Builder chooses a per-stage route:

- Build document: plan, retrieve, write steps, review, commit.
- Word-to-World: the richer existing full-design DSL and orchestration, including its existing repair behavior and limits.
- Volume sketch: the Butter 20 rough-volume and local union compiler.

They are not all forced into volume filling. The build-document builder uses actual retrieved parts and supports optional quaternion orientation. Assembly-specific notes and stage system instructions travel with the request. The document pathway uses medium reasoning, a 12,000-output-token cap and a three-minute request deadline, without automatic paid retries. Repetition records expand locally into exact placements to avoid enumerating identical parts in model output.

## Foraging scope

Retrieval searches the bundled repository index and loaded catalog. It is lexical name/ID retrieval with geometry loading, not a semantic search over the entire internet. Saved committed assemblies in open stages can be retrieved as construction examples; their first steps, provenance and piece counts are included in the selected assembly's context. External LEGO instruction PDFs and the LDraw OMR are not automatically ingested by this release.

Geometry-only pieces are explicitly distinguished from pieces with modeled connectors. Missing connector data is not represented as proof of impossibility. Unknown part IDs that were not retrieved are rejected before geometry construction.

## Checks and unresolved work

- Basic rectangular-brick intersections, stage/envelope violations and known unsupported assemblies block normal commit.
- Conservative bounds involving special shapes and missing connector metadata are labelled uncertain. Keep as unverified geometry is an explicit separate action available only when no hard error exists. The committed revision retains its unverified status.
- Stud connectivity is not a calibrated strength or load simulation. It is not a proof that each part can be inserted in the proposed order.
- Instruction steps accumulate explicit placements unchanged. The final geometry is checked; per-step insertion-path feasibility is not solved.
- Unresolved design obligations remain visible. A geometrically acceptable partial result is labelled Commit partial draft.
- A draft is invalidated for commit if the actual scene or dependency revision changed after it was generated.
- The stage has a 3,000 installed-part cap, assembly budgets up to 500, and up to 32 assemblies. A 1,056-piece three-assembly build, including save/import, was tested. Performance at the maximum on a physical phone is not certified.
- Physics remains paused on document stages so committed coordinates stay stable.
- MPD export contains a main model, named assembly submodels, actual part references and STEP boundaries. It preserves live part geometry; it does not certify assembly order. Deep nested reusable definitions and automatic shared-boundary recompilation are not yet implemented.
- Reference image generation and text design quality were tested with controlled responses only, not paid live API calls.

## Save and stage lifecycle

New blank stage preserves the current stage. Reset keeps a backup stage first. Forking copies the build document and builder choice. Swipe between independent stages as before.

Export document + scene preserves the plan, image reference, retrieval evidence, drafts, committed steps, revisions and actual scene. Open build document imports into a new stage. Export stepped MPD gives LDraw geometry and steps. Export all scenes retains the workspace. Browser quota may fill, especially with images and logs; keep file exports.

This version also fixes a Workshop routing bug: the prior Sketch panel ID did not match the tab router, leaving the tab blank. Visible panel controls are covered by the UI test.

## API / optional gateway

Configure your API connection under Workshop → AI. Concept generation makes a separate image request; the default image model is gpt-image-1 and can be changed. Image access depends on your account and selected model. The new gateway adds /api/images/generations alongside /api/responses.

Node 20+: set OPENAI_API_KEY in the environment, run node server.mjs, open http://127.0.0.1:8787, select Private gateway, and use http://127.0.0.1:8787/api/responses. For network binding configure GATEWAY_TOKEN and ALLOWED_ORIGIN. The package has not been deployed. Never put a private API key into published HTML.

The image pathway follows https://developers.openai.com/api/docs/guides/image-generation and https://developers.openai.com/api/reference/resources/images. LDraw export follows https://www.ldraw.org/article/218.html and https://www.ldraw.org/article/47.html.

## Source / tests

From source/, run python3 make21.py to rebuild the standalone HTML from the Butter 20 base.

- test21.cjs: local instructions, geometry checks, isolated commits, step-preserving MPD, reset/import, fork isolation, persistence, no page scroll.
- test21-ai.cjs: clicks the visible controls from concept request through plan, retrieval, exact steps and commit; checks context images and retrieval packet; verifies invalid geometry remains a draft and cannot commit; verifies the old Sketch tab is visible.
- test21-scale.cjs: repetition expansion, 1,056 installed parts across three commits and scene/document import beyond the former 1,000-piece limit.

Tests use Playwright and runtime-specific Chromium paths. Adapt those paths for your installation. The mocked API tests exercise the real application transport and parsing, but are not live model-quality tests.
