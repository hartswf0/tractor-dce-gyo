# Butter 15

The standalone HTML works with a personal OpenAI API key. Open Workshop → AI → Check connection before generating. A `Failed to fetch` error means the browser did not receive a usable HTTP response; it does not identify whether networking, browser policy, or a dropped connection caused it.

## Try the pieces without an API

Workshop → AI → Test pieces locally previews a 12-piece lighthouse. Press ✓ to place it, or × to discard. This is a bundled test recipe, clearly labeled as a local test. It is not an AI result. If the location is occupied, create an empty scene first.

## Run the private gateway

Requires Node.js 20 or later. No packages to install.

Keep `server.mjs` and `WAG-HAND-BUTTER-15.HTML` together. In a Bash terminal:

```sh
read -s -p 'OpenAI API key: ' OPENAI_API_KEY
export OPENAI_API_KEY
node server.mjs
```

Open http://localhost:8787. In Workshop → AI → Connection route choose **Private gateway**, leave the URL as `http://localhost:8787/api/responses`, and click **Use connection**. Then click **Check connection**. The gateway holds the API key; the browser does not send its OpenAI key to the gateway.

The localhost address is for the machine running Node. It is not a remote endpoint for a phone. To use the gateway from the GitHub Pages app on your phone, deploy this Node server behind HTTPS, set `OPENAI_API_KEY`, a random `GATEWAY_TOKEN`, and `ALLOWED_ORIGIN=https://hartswf0.github.io`. Set `HOST=0.0.0.0` only when needed by the hosting platform. Enter that HTTPS `/api/responses` URL and the gateway token in the app. No gateway has been deployed for you.

The server only forwards Responses creation and single-model checks to OpenAI. It does not expose a general proxy. It checks origins, supports an access token, limits request size, and forwards the response stream without buffering it into a full answer. A remote deployment should enforce its own access and spend controls as well.

## Experiments

Each scene stores a model, reasoning level, system instructions and instruction revision. Duplicate a scene to retain its starting geometry, then change its instructions under AI. Reuse the same prompt to compare approaches. Switching scenes loads that scene's settings. Saving all scenes includes these settings and AI logs; API keys and gateway tokens are excluded.

The engine's geometry and operation rules remain enforced regardless of stage instructions. Logs show the exact effective instructions, request, response events, elapsed time, output operations, usage when returned, and validation failures. A completed or partially received plan can be previewed locally from its log; this does not make another API call. Replays use the active stage and must pass its geometry validation.

## Status

- Connecting: waiting for HTTP response headers.
- Connected: received HTTP status, not yet a completed model answer.
- Accepted: API accepted the request.
- Receiving: complete JSON operations are arriving; drafts are provisional.
- Validating: the complete plan is checked against piece IDs, bounds and collisions.
- Preview: press ✓ to commit or × to discard.

No fake percentage or simulated model reasoning is shown. Connection timeout is 25 seconds, stream inactivity timeout 45 seconds, total request timeout three minutes. Cancellation and failures preserve received output in the log. There are no automatic paid retries.
